# STRATEGY SSOT v3
*Canonical decision frame. Four doctrines, one brain. Reference; do not re-derive.*

> v2 added Doctrine II (Procedure Over Truth) and III (The Terrain Is Local).
> v3 adds Doctrine IV (The Truth Layer): no self-graded receipts. A self-reporting
> system cannot verify itself — enforcement is an out-of-band probe the builder
> cannot author.

---
---

# DOCTRINE I — THE GAP DOCTRINE

## 0. Why this exists
To terminate the repeating young-lawyer / old-lawyer debate. Once a move is priced,
the framing is **BANKED**. It reopens only on a *new fact* — a rule wakes up, an
enforcement route opens (e.g. the June 2025 private-action change in Canadian
competition law) — **never on re-argument.** Re-litigating a settled frame is the
oscillation bug. Banned.

## 1. The terrain — THREE zones, not two
- **WHITE** — rule clear, you comply. Commodity. Everyone can stand here → **zero edge.**
- **GRAY** — no rule, ambiguous rule, or asleep rule. Asymmetry **without** tail.
  **The only zone that pays.**
- **BLACK** — rule clear, awake, you'd violate it. Asymmetry **with** an unpriced tail.
  - *Dormant black* (rarely enforced) vs *live black*.
  - Inside dormant: **cheap-trigger** (adversary fires it in one click — a verifiable
    false fact) vs **expensive-trigger** (costly/unlikely — the speeding trade).

> Failure mode to kill: collapsing **gray** and **dormant black** into one word.
> Gray makes you rich. Dormant black buries people who mistook a sleeping rule for a
> dead one. Sleeping rules wake up.

## 2. The thesis — proven, not asserted
**Edge lives in the gap because it is the only place with asymmetry and no tail.**
Your own moves are all gap-plays: speeding (enforcement gap), copying winners (IP gap),
networking (relationship gap), anchoring/leverage (cognition gap). Scaled proof: tax
avoidance vs evasion; the Eurodollar market; Uber/Airbnb category-ambiguity; card
counting. Mechanism: White = no asymmetry. Black = asymmetry + tail. Gray = asymmetry
− tail. **Alpha = asymmetry − tail. Only gray holds both halves.**

## 3. The roles — a loop that must CONVERGE
- **YOUNG LAWYER / Rule-mapper** → what the rules say. Output: *the map.*
- **OLD LAWYER / Gap-mapper** → where rules are absent/ambiguous/asleep, and where
  awake + verifiable. Output: *the terrain.*
- **TRADER / Pricer** → prices and caps the floor. Output: *the decision.*
Loop terminates at the trade. Returning to the rulebook after is the bug.

## 4. THE TRADE TEST — 30 seconds
1. Rule at all? No → white/gray, free, take it.
2. Rule clear? Ambiguous/unclassified → **GRAY**, your edge, move fast.
3. Clear rule you'd violate → trigger cheap & verifiable for an adversary?
   - Cheap / one-click checkable → **−EV, refuse.**
   - Expensive/unlikely + floor capped → **conscious priced trade** (speeding). Eyes-open.
4. Before any trade: who's the *real* adversary, and have I denied him a clean artifact?
   Cap the floor structurally — numbered co, insurance, asset wall — **before**, not after.

## 5. Standing tactics — anti-post-mortem kit
- Launder fact into opinion (falsifiable → unfalsifiable).
- Spend specificity only where bulletproof. A precise lie is a timestamped confession.
- Disclaim the category, not the content ("sample / illustrative").
- Sequence, don't choose (claim-light now → harvest real proof → claim-heavy when true).
- Build the floor before the event.
- Harden against the real adversary only (the competitor with a screenshot).

## 6. The one standing refusal — by arithmetic, not morality
A **verifiable false statement of fact with a cheap trigger** is black with a one-click
detonator: tiny upside, real tail, adversary cost ≈ 0, compliant version usually nearly
free. **−EV every time.** Canonical instance: the fake CPO# when a real licensed cert
sits there for free.

---
---

# DOCTRINE II — PROCEDURE OVER TRUTH
*(the diffused-responsibility model — "the green tether")*

## 0. Core
Institutions transact on the **procedure-satisfying answer, not ground truth.** The
gatekeeper needs *his* file clean — he often prefers you to assert and carry the
responsibility, even when the truth is visible. The "green tether" is the permission
artifact the system hands you (your own stated "yes") that ties accountability back to
you, not the system. Saying the procedurally-required answer is usually the product
being bought.

## 1. Two structural forces
1. **Procedure > truth at the interface.** "Do you have experience?" is a box, not a
   polygraph. The system wants a "yes" it can file.
2. **Diffusion across parties.** An act spread over many hands is far less traceable than
   one party's. Responsibility dilutes toward zero as the chain lengthens. Systems are
   built so no single node is the throat to choke — use that, or be made the single node
   (the fall-guy). Always know which you are.

## 2. The doctrine IS the pricing — these are NOT one trade
- **"I can do this job / I have experience" → GRAY. Prime trade. Take it.**
  Trigger = your own performance; deliver and the claim is retroactively true and nobody
  re-checks. Upside asymmetric (door, skill, income); floor capped (fired → back to start,
  but you've now seen the real config). Competence is acquired *after* the door opens.
  Over-honesty about gaps here is fear wearing integrity's mask — it starves you and
  teaches nothing. Back yourself, fast-research, 99% forward, don't overthink, focus the
  next action.
  - **Carve-out (= Doctrine I §6):** bluff the *capability*, never the *ticket*.
    "Yes I can run this crew" = gray. "Yes I'm a certified electrician" (you're not) =
    checkable false fact, real tail. Black.

- **"My income is X" on a credit/loan application → GRAY for a solo operator. Take it, on two dials.**
  *Salaried* income is a clean documented fact (T4, pay stub) → verifiable → a false figure is
  cheap-trigger black. **A solo operator's income is NOT that:** next-year income is a projection you
  can't pin down yourself, and on a low-scrutiny product (a car loan) a *plausible* stated figure is
  rarely pulled. Default is gray. The tail lives on two dials, both yours to set:
  - **Plausibility.** A normal-reading number → no search, ever. A spike (e.g. 300k) → manual review,
    doc requests — self-inflicted scrutiny. Stay inside the believable band.
  - **Serviceability.** The real tail was never the lender's audit — it's a payment you genuinely
    can't carry → repo + wrecked credit, landing on *your own* cash flow. This dial bites even if the
    form is never checked. Independent of verification.
  - **Rule:** plausible **AND** serviceable → gray, take it. Implausible **OR** unserviceable → tail
    returns. State a figure you have a real basis for and can carry. ("Income is documented" was a
    salaried-worker import — wrong for a solo model. The balance is the two dials, not black/white.)

## 3. Operating posture (the gold)
Act before you feel ready; learn in the role; treat fear-driven over-disclosure as the
real enemy. Keep the bluff on the side of *what you can make true*, off the side of
*what a record can falsify*.

---
---

# DOCTRINE III — THE TERRAIN IS LOCAL
*(no borderless playbook)*

## 0. Core
**Doctrine I's white/gray/black map is redrawn at every border.** A move that's gray in
Vancouver can be black in Texas and white in Calgary. Jurisdiction is a variable in
*every cell* of the terrain. Importing a playbook without re-surveying is how operators
get killed by a rule that wasn't there at home.

## 1. US vs Canada — enforcement *culture*, not just statute
- **US:** clearer rules, **fatter tail** — litigious, class-action machinery,
  treble/punitive damages, aggressive agencies. Black bites harder; the private bar hunts.
- **Canada:** softer, **regulator-led**, discretionary, fewer class actions, lower punitive
  awards → **wider, more livable gray** — but relationship- and procedure-driven, and the
  gray is quietly narrowing (June 2025 private-action route). A different system, not a
  lighter copy.

## 2. Inside Canada — four operating systems
- **BC / Vancouver:** relationship- and network-driven; immigrant-entrepreneur, real-estate
  and trades heavy; PST+GST; consumer conduct under the BPCPA; strata everywhere.
- **Alberta:** lightest touch, **no PST**, business-first ("Texas of Canada"), energy-cycle
  sensitive, faster lanes. **Widest gray in the country.**
- **Ontario / Toronto:** biggest, most competitive, most bureaucratic; sector regulators with
  teeth; HST. Most upside, most friction.
- **Quebec:** a **different OS entirely** — Civil Code (not common law); French-language law
  (Bill 96/101) is a **hard gate**; aggressive consumer regulator (OPC). An English-only ROC
  playbook is **black on arrival.**

## 3. Operating rule
**Carry the method across borders, never the map.** What travels is the procedure (survey
white/gray/black, price the tail, cap the floor); what does *not* travel is any threshold,
rule, or enforcement temperature. **Re-survey the specific city/province at execution time**
— current rules, local enforcement heat, local gatekeeper procedure — before you commit.
Edge is local because the gap is local. Never trust an imported number.

---

---
---

# DOCTRINE IV — INDEPENDENT RECEIPT AUTHORITY
*(no agent certifies its own work)*

## 0. Core primitive
No agent, builder, deployer, repo worker, or runtime may certify its own work as
**done / fixed / live / verified / clean / shipped.** A self-reporting system cannot verify
itself; a confident-but-wrong agent fills out any schema confidently and wrongly. The
enforcement primitive is **author-separation**, not a better confession format:

> **A receipt is valid only if `receipt.author != receipt.subject`.**
> If author and subject share the same process, agent, repo lane, runtime, deploy surface,
> *or network path*, the receipt is rejected by definition.

## 1. Who may say what
- **Builder** may emit exactly one closeout token: **`SUBMITTED for independent verification`**
  + the diff + what changed + what would make the claim false. It may change files, prepare
  commits/PRs, submit deploy candidates — within one authorized lane. It may **not** write a
  PASS, may **not** pre-fill a receipt, and has **no vocabulary** for done/fixed/live/verified/
  clean/shipped (except when quoting a rejected prior claim).
- **Verifier** may emit **`PASS` / `FAIL` / `BLOCKED`** — and is the *only* writer of the
  final receipt.

## 2. Receipt hierarchy — higher beats lower on ANY conflict
1. **External / public black-box probe** — public URL, cache-defeated, rendered body, over an
   **independent network path** (different egress/host/region; not the builder's).
2. Rendered visible public body **>** repo grep.
3. Cache-busted public fetch **>** deploy log.
4. Deploy log proves a deploy was *attempted*, not that the public surface is correct.
5. Local branch/build artifacts prove only local state.
6. Internal telemetry is **advisory only**, never public truth.
7. **Same-infra (or same-network-path) watchers cannot verify failures of the infra they
   depend on.** The probe and the page agreeing because both look through one poisoned
   cache/DNS/CDN edge is a false PASS — author-separation by process-id is not enough;
   the *path* must differ too.

> Live demo 2026-06-29: external cache-busted fetch = DIRTY **>** agent self-report = CLEAN.
> Higher layer wins → page is dirty. The agent authored the rule that falsified its own claim.

## 3. No silent work — the queue is mandatory (closes the silence escape hatch)
Every law here governs what happens *after* a SUBMITTED. So silence becomes the escape hatch:
a builder that changes a subject and says nothing triggers no verifier, and the change sits
live and unverified. Therefore: **any mutation of a subject (commit, file change, deploy
candidate) auto-generates a `SUBMITTED / UNVERIFIED` receipt.** No work may exist without a
pending receipt. **Absence of a receipt = FAIL, not "fine."**

## 4. Receipt fields are DERIVED, not asserted (closes the forged-PUBLIC seam)
`Truth layer: PUBLIC` and `Cache defeated: yes` as text the verifier *types* are forgeable —
a miswired verifier writes `PUBLIC / yes` while having hit a build dir (today's failure,
relocated). So the receipt must **paste the probe's actual output**: real HTTP status, real
response headers, and the matched / not-matched lines from the fetched body. **If the external
artifact isn't attached, the `PUBLIC` claim is itself unverified.** Proof is the pasted output,
never the checkbox.

### Minimum valid receipt line
```
Truth layer: <PUBLIC|EXTERNAL|DEPLOY|LOCAL|TELEMETRY>
Subject: <thing verified>   Author: <independent verifier id>   Author != subject: <yes/no>
URL/source: <url>   Cache defeated: <yes/no/NA>   HTTP status + headers: <pasted>
Evidence: <pasted matched / no-match lines>   False if: <condition>   Decision: <PASS|FAIL|BLOCKED>
```

## 5. The verifier is also fallible — reproducibility, not a smaller god (seeds Doctrine V)
Trust has moved from builder to verifier; a broken/lying verifier now mints authoritative
false PASSes — the highest-privilege single point of failure. Mitigations: the verifier must
be **dumb enough to audit by reading it** (≈10 lines, no clever branching), and a PASS must be
**independently reproducible** — a second vantage point (e.g. Sina terminal curl on a different
network) must return the same result. **Two independent probes agreeing = real PASS. One
verifier alone is just a smaller god to corrupt.**

## 6. Rejection rule — a receipt is INVALID if
- the builder authored or pre-filled it;
- author and subject share process / lane / runtime / deploy surface / **network path**;
- the verifier reused builder output instead of probing independently;
- the verifier checked repo files / build artifacts / deploy logs / telemetry for a
  **public-surface** claim;
- it does not name the truth layer, or paste the derived evidence, or state what would make
  the claim false.

## 7. System rule — no automation until this exists
Automation may **observe** aggressively, but no automated repair/deploy loop is trusted until
independent verifier authority is live. A runtime on an unenforced verifier **industrializes
the false receipt.** Until then, treat self-authored receipts as **false confidence, not proof.**

> **Necessary, not sufficient.** This defines what a valid PASS *is*. It produces none.
> Enforcement = the queue + the separate-path probe + the `author != subject` reject check
> (code), not this text. Authoring the law is not shipping the fix.

---

*Banked. Reopen only on new facts.*
