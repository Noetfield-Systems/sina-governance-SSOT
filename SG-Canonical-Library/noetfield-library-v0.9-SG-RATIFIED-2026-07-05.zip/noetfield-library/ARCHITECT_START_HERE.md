# ⭐ ARCHITECT — START HERE (read this first, every new chat/session/app)

**Purpose:** the minimum spine so ANY architect (Claude in a new chat, another AI app, a Cursor agent) is instantly oriented and does NOT get confused, lost, or duplicate work. If you read only one file, read this one, then open what it points to.

**Owner:** Sina Kazemnezhad · **Updated:** 2026-07-04 16:13 PDT · **This file = read-surface pointer, not authority.**

---

## 0. THE ONE RULE FOR NEW SESSIONS (anti-drift)
Everything here is ONE continuous thread built layer-by-layer. **Do not re-derive, do not re-argue settled framing, do not treat a new chat as a new project.** (SSOT v6 invariant 0.4: banked frames reopen only on a NEW FACT.) A new chat losing context is a *continuity* problem, not a signal to rebuild. Read the spine, then continue.

## 1. AUTHORITY ORDER (lower number wins on conflict)
```
P0 FOUNDATION-SPINE  ← the constitution (SSOT v6) + index + L0 runtime + governed-autorun
P1 CANON             ← FOUNDER_CANON v1 (operational master) + operating plan + machine loops + work order + brain registry
P2 SSOT              ← ratified rules (R-split, versioning) + SSOT v2–v6 history + D4 package + gap-doctrine
P3 RUNTIME-REALITY-L0← what runs TODAY (Mac Workbench)
P4 CLOUD-KERNEL      ← SSOT v1.2 (master arch, LOCKED) + Cloud Kernel v1.3 (target)
P5 LINE-ENGINE       ← how agents execute (exec-contract, blueprint-registry, IDE lane, roles)
P6 BRAIN-MEANING     ← locked-definitions (the deterministic brain's meaning source)
P7 DOCTRINE          ← the thinking laws
P8 MACHINE-LOOPS     ← validation/critique/repair/audit/research + 5-stage loop + E2E registry
P9 PATTERN-FACTORY   ← the sellable patterns
P10 PRODUCT-LAYERS   ← SourceA / Noetfield / TrustField(separate co) + strategy
P99 LEDGER           ← receipts, decisions, audits, reconciliations
```

## 2. THE NON-NEGOTIABLE INVARIANTS (SSOT v6 Level 0 — bind everything)
- **0.1 Author ≠ Subject** — nothing certifies its own work (process/lane/runtime/deploy/network path all differ).
- **0.2 Sina owns DECIDE** — agents do everything reversible; only Sina triggers the irreversible.
- **0.3 Reality > report** — external reality beats any self-report; highest truth-layer wins.
- **0.4 Banked frames reopen only on new facts** — no oscillation, no re-arguing settled things.
- **0.5 Convergence = warning, not confirmation** — correlated agreement (incl. multi-AI) is a red flag to stress-test.
- **0.6 Removal is free** — subtraction permitted without the ceremony addition needs; assertion is gated.


## 2b. THE MIND — P0 CORE (read only if you are Base Brain or a high decision agent)
`P0-FOUNDATION-SPINE/P0-CORE/FOUNDER_JUDGMENT_PATTERNS_v1.md` = how Sina judges when no Tier-1 rule fits. 10 patterns, each harvested from a real case. **Workers must NEVER load this** (least-knowledge). It grows by HARVEST only — never write a pattern speculatively.
`P0-FOUNDATION-SPINE/AGENT_LAYERED_LAW…LOCKED_v1.md` = the meta-law: which agent reads which law (Tier 0/1/2/3 + least-knowledge). It routes every other law. This is why no agent reads everything.

## 3. THE CORE THESIS (what we're building, in 5 lines)
- A **raw deterministic brain** (empty core + Sina's locked definitions) that decides; **LLMs are soup-walled workers** that only draft/execute, never hold meaning.
- **Contracts run the system; LLMs only propose.** The Execution Contract holds authority.
- **Receipts, not diagrams; mechanical, not prose; proven by rejection (negative proof).**
- **Run 24/7 pursuing targets; stop only for genuine harm (a blocker).** The floor is immutable — a self-improving system can't weaken its own brakes.
- Business = **pattern factory**: prove patterns (zero-drift, anti-theater, auto-heal) on our own lines, sell them; Sina = native-pattern-thinker/trader.

## 4. NO TECHNICAL BLOCKER — THE GAP IS COMMERCIAL (the real target)
SUPABASE_URL is FIXED (2026-07-04). There is no remaining technical blocker. **The real missing piece is the REVENUE ORGAN** — lead intake → offer → close → revenue receipt. The system is fully built on the DELIVER side and has produced ZERO revenue receipts. Survival now = first dollar. Build order: SINA_GATEWAY (lead intake) → sell 10 Brain Audits → let ROI heal on real signal. See `P99-LEDGER/THE_REAL_DIAGNOSIS_revenue-organ`.

## 5. COMMERCIAL LADDER (what's sellable when)
Brain Audit **now** → prove Zero-Drift on SourceA → Operating Brain Install → SourceA 24/7 w/ receipts → Managed Brain → VIP Architecture. (`P9-PATTERN-FACTORY/`)

## 6. ENTITY FACTS (don't confuse)
- **Noetfield Systems Inc.** — D-U-N-S 243370005, Active, Vancouver BC. The parent / pattern factory.
- **TrustField Technologies Inc.** — SEPARATE company Noetfield serves (NOT a subsidiary/product).
- **SourceA** — product under Noetfield (Forge, WitnessBC, 777 = brands/skins).

## 7. HOW TO NOT DUPLICATE / GET LOST
1. Read this file + `00-INDEX.md` + `BIG_PICTURE_RELATION_MAP.md`. That's the orientation set.
2. Before writing anything new, check if it exists in its P-tier. If it does, EDIT (new version + datetime), don't recreate.
3. **Authority = registry + receipt, not file existence.** A file on disk isn't law until SG-registered.
4. Sandbox/chat work is a PROPOSAL until reconciled to disk (disk-registered wins).
5. Version everything: `v{major}.{minor}.{edit}_{YYYYMMDD-HHMM}` in filename + header + edit-log.

## 8. THE SESSION LOOP (how a working session runs)
`CHECK → ANALYZE → CRITIQUE → SPEC → VERIFY → DECIDE(Sina) → STOP` — reopens on a new fact only. (D5 operating loop; the amber DECIDE is the only Sina step.)

---
*v0.1 (2026-07-04 16:13 PDT) — portable architect-orientation spine so any chat/app/agent gets the most important subjects immediately. Read-surface pointer; authority lives in P0–P2.*
